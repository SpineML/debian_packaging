This directory is in place and contains SpineML/tools which is a symlink to
../../tools and is present to allow running spineml-2-brahms in-place.
