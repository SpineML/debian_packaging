#!/bin/bash

brahms --d --par-NamespaceRoots=/home/seb/greenbrain/SpineML_2_BRAHMS/tools test_readfile_exe.xml
